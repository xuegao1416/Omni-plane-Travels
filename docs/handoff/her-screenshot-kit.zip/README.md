# 截图工具包 / Screenshot kit

给另一台机器用的**最小可用截图台**。12 个文件，22 KB，**零依赖**。

原本那套活在她自己的 `C:\tmp\imp` 和 `D:\shots\tools` 里，只打包项目源码是带不过去的。
这份是把她那套里**通用**的部分抽出来，去掉写死的路径，换成任意机器能跑的版本。

---

## 前提

| 需要 | 检查 |
|---|---|
| **Bun** | `bun --version` |
| **Microsoft Edge** | 装了就成，路径自动探测两个常见位置 |
| **dev server 在跑** | `curl http://localhost:3457/` 返回 200 |
| **Python + Pillow** | 只有 `sheet.py` 需要：`pip install pillow` |

不需要：node_modules、playwright、puppeteer、任何 npm 包。

---

## 三个主力，分别管三件事

```bash
# ① 截图 —— 最常用，占了 90% 的场景
bun shot.ts <url> <out.png> [WxH] [waitMs] [expr]

# ② 性能 —— 想知道某屏是不是卡
bun perf.ts <url> [WxH] [settleMs] [sampleMs] [actionExpr]

# ③ 改 CSS —— 按正则批量删选择器
bun css-strip.ts <file.css> <regex> [--dry]
```

```bash
bun shot.ts "http://localhost:3457/?plshot=hall" hall.png
bun shot.ts "http://localhost:3457/?plshot=combat&stage=active" c.png 390x844 5000
bun shot.ts "http://localhost:3457/?plshot=game" g.png 1440x900 3000 "document.querySelectorAll('input').length"

bun perf.ts "http://localhost:3457/?plshot=hall" 1440x900 2500 4000
bun css-strip.ts src/ui/screens/combat.css '^\.cb-legacy' --dry
```

**出图空白 → 把 waitMs 加大。** 这个应用 1800ms 通常不够，动效要 3000–5000。

---

## 完整文件清单

### 基础（一定会用到）

| 文件 | 干什么 | 何时用 |
|---|---|---|
| `shot.ts` | 截图 + 可选求值 | 每次要"看看现在什么样" |
| `cdp-seed.ts` | 种子截图：写 localStorage → reload → 截 | 要跳过引导/预置存档状态时 |
| `perf.ts` | 主线程耗时 + 帧率（p50/p95/max/over20） | 怀疑某屏卡 |

### 验证（只在"必须零变化"时用）

| 文件 | 干什么 | 何时用 |
|---|---|---|
| `dump.js` | 48 个 computed style 全量快照 → JSON | 清理 `!important` 那种"不许变"的活 |
| `cmp.py` | 比对两份快照，打印逐属性差异 | 同上 |
| `btn.js` | `press('按钮文字')` | 需要先点开菜单/弹窗再抓 |
| `dumppre.sh` | 把 `btn.js` + 预动作拼进 `dump.js` | 同上，**要 bash/WSL** |

### 辅助

| 文件 | 干什么 |
|---|---|
| `sheet.py` | 多张截图拼成一张总览图（**省 context 的关键**） |
| `css-strip.ts` | 按正则从每条规则里删选择器，空规则和空 `@media` 一起删 |
| `cdp.ts` / `cdp-eval.ts` | 她的原版驱动，保留作对照（路径写死，换机要改 2 行） |

### 没打进来的（特供，换项目就废）

`weave.ts` / `workshop.ts` / `dive.ts` / `guided.ts` / `mem-*.js` / `js-npc*.js` / `seed.sh` / `mock-ai.ts` ——
这些全部写死了本项目的按钮文字、类名、localStorage 键名。**换机器能用，换项目不能用**，所以没必要带。
真需要的话，照着 `shot.ts` 的用法现写一个更快。

---

## 用 dump.js + cmp.py 做"零变化"验证

只在需要**证明某个改动没有改变任何外观**时才用。单纯做重制不需要 —— 重制的意图就是要变。

```bash
# 1. 改之前抓快照
bun shot.ts "http://localhost:3457/?plshot=game&panel=notebook" base/nb.png 1440x900 4000 \
  "(()=>{$(cat dump.js)})()" > base/nb.json

# 2. 改之后抓同一屏
# 3. 比对
python cmp.py base/nb.json after/nb.json
```

**注意 `dump.js` 的接法**：它本身就是一个表达式，不是模块。要把它的内容塞进 `Runtime.evaluate` 的 expression 里，不是 `import` 它。

---

## 教训（花过钱换来的）

**① 先量噪声底，再动手。**
抓完基线后**什么都不改再抓一遍**，比对结果就是噪声底。
这个应用里 `wizard` 屏有入场动画，两次抓必然有 ±0.1px 的 `transform` / `opacity` 漂移。
不先量这一遍，你会把动画抖动当成自己改坏了。

**② 别整屏死拍。**
一屏一屏截图再挨个看，是最贵的做法（读图成本远高于读数字）。
**把 12 屏拼成一张总览图**（`sheet.py`）再读一次，能省一个数量级。

**③ 比对用数字，不用眼睛。**
`cmp.py` 的输出是 `28.7 万个属性值里只有 2 个变了，且是动画噪声` —— 这种结论人眼永远给不出来。

**④ 无头 Edge 崩了会残留进程。**
跑完还占内存就 `Get-Process msedge | Stop-Process -Force`。16G 笔记本上这点很要紧。

**⑤ 别起长时间的后台 helper。**
一次实测：后台 helper 跑了 156 分钟烧掉 441 积分，只清完 79 处；
停下来她自己干，剩下 88 处用了 40 分钟。**"造车"要钱，"开车"不要钱。**

---

## 跨机适配改了什么

原版写死三处，这两台机器之间不通用：

| 原版 | 改成 |
|---|---|
| `--user-data-dir=D:/shots/prof-${port}` | `os.tmpdir()/cdpshot-${port}`（`perf.ts` 是 `perf-${port}`） |
| 只认 `C:/Program Files (x86)/…` | 两个候选路径都试，取存在的那个 |
| `window.confirm()` 会永久挂住 `Runtime.evaluate` | 收到 `Page.javascriptDialogOpening` 就 `accept: true` |

⚠️ **`PORT` 必须先声明再算 `profileDir`** —— 我第一次改的时候把顺序弄反了，直接 `ReferenceError: port is not defined`。

---

## 本机实测记录

```
shot.ts   → val 85 / ok ... 738KB / 退出码 0
手机档    → ok ... 126KB
perf.ts   → {"per_second_ms":{"task":"4.8","script":"0.8"},"frames":{"n":74,"p50":16.7,"p95":17,"over20":2}}
解压后    → ok C:\WINDOWS\TEMP\kitcheck_xxx\out.png 739KB ✓
```
