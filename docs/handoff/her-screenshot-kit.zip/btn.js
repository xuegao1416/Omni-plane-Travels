const norm = s => (s || '').replace(/\s+/g, '');
const btn = t => [...document.querySelectorAll('button')].find(b => norm(b.textContent).includes(norm(t)));
const press = async (t, ms = 900) => { const b = btn(t); if (b) b.click(); await sleep(ms); return !!b; };
