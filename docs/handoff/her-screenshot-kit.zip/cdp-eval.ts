// Minimal CDP screenshot driver for Edge. Usage:
//   bun D:/shots/tools/cdp.ts <url> <out-prefix> <w>x<h> <waitMs> [frames] [intervalMs] [clickX,clickY]
// Takes one shot after waitMs, or `frames` shots every intervalMs (after an optional click).
const [url, out, size = "1440x900", waitArg = "4000", expr = "1"] = process.argv.slice(2); const framesArg="1", intervalArg="100", click=undefined as any;
const [w, h] = size.split('x').map(Number);
const port = 9300 + Math.floor(Math.random() * 500);
const edge = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const proc = Bun.spawn([edge, '--headless=new', '--disable-gpu-sandbox', '--hide-scrollbars', `--remote-debugging-port=${port}`,
  `--user-data-dir=D:/shots/prof-${port}`, `--window-size=${w},${h}`, 'about:blank'], { stdout: 'ignore', stderr: 'ignore' });
let target: any;
for (let i = 0; i < 50 && !target; i++) {
  await Bun.sleep(200);
  try { target = (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find((t: any) => t.type === 'page'); } catch { /* not up */ }
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise(r => (ws.onopen = r));
let id = 0; const pending = new Map<number, (v: any) => void>();
ws.onmessage = e => { const m = JSON.parse(String(e.data)); if (m.id && pending.has(m.id)) { pending.get(m.id)!(m.result ?? m.error); pending.delete(m.id); } };
const send = (method: string, params: any = {}) => new Promise<any>(r => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: w < 700 });
await send('Page.navigate', { url });
await Bun.sleep(Number(waitArg));
if (click) {
  const [x, y] = click.split(',').map(Number);
  for (const type of ['mousePressed', 'mouseReleased']) await send('Input.dispatchMouseEvent', { type, x, y, button: 'left', clickCount: 1 });
}
const frames = Number(framesArg);
for (let i = 0; i < frames; i++) {
  const r = await send('Page.captureScreenshot', { format: 'png' });
  await Bun.write(frames > 1 ? `${out}-${String(i).padStart(2, '0')}.png` : `${out}.png`, Buffer.from(r.data, 'base64'));
  if (i < frames - 1) await Bun.sleep(Number(intervalArg));
}
const logs = await send('Runtime.evaluate', { expression: expr, returnByValue: true });
console.log('ok', logs?.result?.value ?? '');
ws.close(); proc.kill();
process.exit(0);
