// bun cdp-seed.ts <url> <out> <WxH> <waitMs> <seedExpr> [afterExpr]
const [url, out, size = '1440x900', waitArg = '4000', seed = '1', after = ''] = process.argv.slice(2);
const [w, h] = size.split('x').map(Number);
const port = 9300 + Math.floor(Math.random() * 500);
const edge = 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const proc = Bun.spawn([edge, '--headless=new', '--disable-gpu-sandbox', '--hide-scrollbars', `--remote-debugging-port=${port}`, `--user-data-dir=D:/shots/prof-${port}`, `--window-size=${w},${h}`, 'about:blank'], { stdout: 'ignore', stderr: 'ignore' });
let target: any;
for (let i = 0; i < 50 && !target; i++) { await Bun.sleep(200); try { target = (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find((t: any) => t.type === 'page'); } catch {} }
const ws = new WebSocket(target.webSocketDebuggerUrl); await new Promise(r => (ws.onopen = r));
let id = 0; const pending = new Map<number, (v: any) => void>();
ws.onmessage = e => { const m = JSON.parse(String(e.data)); if (m.method === 'Page.javascriptDialogOpening') ws.send(JSON.stringify({ id: 99999, method: 'Page.handleJavaScriptDialog', params: { accept: true } })); if (m.id && pending.has(m.id)) { pending.get(m.id)!(m.result ?? m.error); pending.delete(m.id); } };
const send = (method: string, params: any = {}) => new Promise<any>(r => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: w < 700 });
await send('Page.navigate', { url }); await Bun.sleep(1500);
await send('Runtime.evaluate', { expression: seed });
await send('Page.reload'); await Bun.sleep(Number(waitArg));
let res = '';
if (after) { const r = await send('Runtime.evaluate', { expression: after, returnByValue: true, awaitPromise: true }); res = JSON.stringify(r?.result?.value ?? r); await Bun.sleep(600); }
const r = await send('Page.captureScreenshot', { format: 'png' });
await Bun.write(`${out}.png`, Buffer.from(r.data, 'base64'));
console.log('ok', res); ws.close(); proc.kill(); process.exit(0);
