import json, sys, os
# usage: cmp.py <beforeDir> <afterDir> [name...]
b, a = sys.argv[1], sys.argv[2]
names = sys.argv[3:] or sorted(f[:-5] for f in os.listdir(b) if f.endswith('.json'))
for n in names:
    try:
        B = json.load(open(os.path.join(b, n + '.json'), encoding='utf-8'))
        A = json.load(open(os.path.join(a, n + '.json'), encoding='utf-8'))
    except Exception as e:
        print(f'## {n}: load error {e}'); continue
    props = B['props']; bo, ao = B['out'], A['out']
    diffs = []
    for k in bo:
        if k in ao and bo[k] != ao[k]:
            bv, av = bo[k].split('|'), ao[k].split('|')
            d = [f'{props[i]}: {bv[i]} -> {av[i]}' for i in range(len(props)) if bv[i] != av[i]]
            diffs.append((k, d))
    only_b = [k for k in bo if k not in ao]; only_a = [k for k in ao if k not in bo]
    print(f'## {n}: {len(bo)} els, {len(diffs)} changed, -{len(only_b)} +{len(only_a)}')
    for k, d in diffs[:40]:
        print('  ', k[-140:]); [print('      ', x[:220]) for x in d]
    for k in only_b[:5]: print('   - ', k[-140:])
    for k in only_a[:5]: print('   + ', k[-140:])
