// bun css-strip.ts <file> <regex> [--dry]
// Removes selectors matching regex from every rule; rules left with no selector are dropped,
// and @media/@supports blocks that become empty are dropped too.
const [file, pattern, flag] = process.argv.slice(2);
const re = new RegExp(pattern);
const src = await Bun.file(file).text();
let removed = 0;

function blockEnd(start: number) {
  let depth = 0;
  for (let j = start; j < src.length; j++) {
    const c = src[j];
    if (c === '/' && src[j + 1] === '*') { j = src.indexOf('*/', j + 2) + 1; continue; }
    if (c === '"' || c === "'") {
      const q = c; j++;
      while (j < src.length && src[j] !== q) { if (src.charCodeAt(j) === 92) j++; j++; }
      continue;
    }
    if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) return j + 1; }
  }
  return src.length;
}

function walk(s: number, e: number): string {
  let res = '';
  let k = s;
  while (k < e) {
    const ws = /^\s+/.exec(src.slice(k, Math.min(e, k + 4000)));
    if (ws) { res += ws[0]; k += ws[0].length; continue; }
    if (src.startsWith('/*', k)) { const end = src.indexOf('*/', k + 2) + 2; res += src.slice(k, end); k = end; continue; }
    if (src[k] === '}') { k++; continue; }
    const brace = src.indexOf('{', k);
    const semi = src.indexOf(';', k);
    if (brace === -1 || brace >= e || (semi !== -1 && semi < brace)) {
      const end = semi === -1 || semi >= e ? e : semi + 1;
      res += src.slice(k, end); k = end; continue;
    }
    const prelude = src.slice(k, brace);
    const end = blockEnd(brace);
    const p = prelude.trim();
    if (p.startsWith('@')) {
      if (/^@(media|supports|layer|container)/.test(p)) {
        const inner = walk(brace + 1, end - 1);
        if (inner.replace(/\/\*[\s\S]*?\*\//g, '').trim() === '') removed++;
        else res += prelude + '{' + inner + '}';
      } else res += src.slice(k, end);
    } else {
      const sels = prelude.split(',');
      const keep = sels.filter(sel => !re.test(sel));
      if (keep.length === 0) removed++;
      else if (keep.length < sels.length) { removed++; res += keep.map(x => x.trim()).join(',\n') + ' ' + src.slice(brace, end); }
      else res += src.slice(k, end);
    }
    k = end;
  }
  return res;
}

const out = walk(0, src.length).replace(/\n{3,}/g, '\n\n');
if (flag !== '--dry') await Bun.write(file, out);
console.log(file, 'rules touched', removed, 'lines', src.split('\n').length, '->', out.split('\n').length);
