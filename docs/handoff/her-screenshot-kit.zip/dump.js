(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = s => document.querySelector(s);
  const click = el => el && el.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  /*PRE*/
  const props = ['display','position','width','height','min-height','max-height','padding-top','padding-right','padding-bottom','padding-left','margin-top','margin-right','margin-bottom','margin-left','border-top-width','border-top-style','border-top-color','border-left-width','border-radius','color','background-color','background-image','box-shadow','font-family','font-size','font-weight','line-height','letter-spacing','text-transform','white-space','gap','row-gap','column-gap','grid-template-columns','transform','filter','opacity','overflow-x','overflow-y','align-items','text-shadow','clip-path','text-align','order'];
  const out = {};
  const path = el => { const parts = []; while (el && el.nodeType === 1 && el !== document.documentElement) { let i = 0, s = el; while ((s = s.previousElementSibling)) i++; parts.unshift(el.tagName.toLowerCase() + (el.classList.length ? '.' + [...el.classList].join('.') : '') + ':' + i); el = el.parentElement; } return parts.join('>'); };
  for (const el of document.body.querySelectorAll('*')) {
    if (el.closest('svg') && el.tagName.toLowerCase() !== 'svg') continue;
    const cs = getComputedStyle(el);
    out[path(el)] = props.map(p => cs.getPropertyValue(p)).join('|');
  }
  return { props, out };
})()
