#!/bin/sh
# usage: dumppre.sh <outdir> <name> <query> <w> <h> <preJsFile>
D="$1"; mkdir -p "$D"
python -I -c "import sys;s=open('C:/tmp/imp/dump.js',encoding='utf-8').read();open(sys.argv[2],'w',encoding='utf-8').write(s.replace('/*PRE*/',open('C:/tmp/imp/pre/btn.js',encoding='utf-8').read()+open(sys.argv[1],encoding='utf-8').read()))" "$6" "$D/_expr.js"
INIT="$INIT" SEED="$SEED" node C:/tmp/imp/cdp2.mjs "$D/$2.png" "$3" $4 $5 4000 "@$D/_expr.js" > "$D/$2.json" 2>/dev/null; taskkill //IM msedge.exe //F >/dev/null 2>&1
