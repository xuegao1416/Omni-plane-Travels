// bun perf.ts <url> <WxH> [settleMs] [sampleMs] [actionExpr]
// Reports main-thread cost while idle (or during an action) via CDP Performance metrics + rAF frame stats.
const [url, size = '1440x900', settleArg = '2500', sampleArg = '4000', action = ''] = process.argv.slice(2);
const [w, h] = size.split('x').map(Number);
const port = 9333 + Math.floor(Math.random() * 400);
const _os = require('node:os'); const _path = require('node:path');
const _cand = ['C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe','C:/Program Files/Microsoft/Edge/Application/msedge.exe'];
const edgePath = _cand.find(p => require('node:fs').existsSync(p)) ?? _cand[0];
const profileDir = _path.join(_os.tmpdir(), `perf-${port}`);
const chrome = Bun.spawn([edgePath, '--headless=new', '--disable-gpu-sandbox', `--remote-debugging-port=${port}`, '--no-first-run', '--no-default-browser-check', `--user-data-dir=${profileDir}`, 'about:blank'], { stdout: 'ignore', stderr: 'ignore' });
let target: any;
for (let i = 0; i < 50 && !target; i++) { await Bun.sleep(200); try { target = (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find((t: any) => t.type === 'page'); } catch {} }
const ws = new WebSocket(target.webSocketDebuggerUrl); await new Promise(r => (ws.onopen = r));
let id = 0; const pending = new Map<number, (v: any) => void>();
ws.onmessage = e => { const m = JSON.parse(String(e.data)); if (m.id && pending.has(m.id)) { pending.get(m.id)!(m.result); pending.delete(m.id); } };
const send = (method: string, params: any = {}) => new Promise<any>(r => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
await send('Page.enable'); await send('Performance.enable');
await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: w < 700 });
await send('Page.navigate', { url }); await Bun.sleep(Number(settleArg));
const metrics = async () => Object.fromEntries((await send('Performance.getMetrics')).metrics.map((m: any) => [m.name, m.value]));
const frameProbe = `(()=>{window.__f=[];let last=performance.now();const tick=t=>{window.__f.push(t-last);last=t;if(window.__f.length<100000)requestAnimationFrame(tick)};requestAnimationFrame(tick);return 1})()`;
await send('Runtime.evaluate', { expression: frameProbe });
const a = await metrics();
if (action) await send('Runtime.evaluate', { expression: action, awaitPromise: true });
await Bun.sleep(Number(sampleArg));
const b = await metrics();
const frames = (await send('Runtime.evaluate', { expression: `JSON.stringify((()=>{const f=window.__f.slice(1);const s=[...f].sort((x,y)=>x-y);return {n:f.length,p50:s[Math.floor(s.length*.5)],p95:s[Math.floor(s.length*.95)],max:s[s.length-1],over20:f.filter(x=>x>20).length}})())`, returnByValue: true })).result.value;
const secs = Number(sampleArg) / 1000;
const d = (k: string) => ((b[k] - a[k]) * 1000 / secs).toFixed(1);
console.log(JSON.stringify({ per_second_ms: { task: d('TaskDuration'), script: d('ScriptDuration'), style: d('RecalcStyleDuration'), layout: d('LayoutDuration') }, recalcs_per_s: ((b.RecalcStyleCount - a.RecalcStyleCount) / secs).toFixed(1), layouts_per_s: ((b.LayoutCount - a.LayoutCount) / secs).toFixed(1), frames: JSON.parse(frames) }));
ws.close(); chrome.kill();
