import sys
from PIL import Image
out=sys.argv[1]; files=sys.argv[2:]
ims=[Image.open(f).convert('RGB') for f in files]
w=960; rows=[]
for im in ims:
    r=w/im.width; rows.append(im.resize((w,int(im.height*r))))
cols=2; cw=w; 
import math
n=len(rows); R=math.ceil(n/cols)
H=[max(rows[i].height for i in range(r*cols,min(n,(r+1)*cols))) for r in range(R)]
S=Image.new('RGB',(cw*min(cols,n),sum(H)),(40,0,40))
y=0
for r in range(R):
    for c in range(cols):
        i=r*cols+c
        if i<n: S.paste(rows[i],(c*cw,y))
    y+=H[r]
S.save(out); print(S.size)
