// Portable CDP screenshot driver for Edge. Zero dependencies — only needs `bun` and Edge.
// Portable: profile dir goes to the OS temp dir, so it works on any machine / any drive layout.
//
// USAGE
//   bun shot.ts <url> <out.png> [WxH] [waitMs] [expr]
//
//   url      page to open, e.g. "http://localhost:3457/?plshot=combat"
//   out.png  output path, e.g. "D:/shots/combat.png"
//   WxH      viewport, default 1440x900. Use 390x844 for a real phone layout.
//   waitMs   settle time before the shot, default 4000. Animations need more.
//   expr     optional JS to run before the shot; its value is printed as `val ...`
//
// EXAMPLES
//   bun shot.ts "http://localhost:3457/?plshot=hall" hall.png
//   bun shot.ts "http://localhost:3457/?plshot=combat&stage=active" c.png 390x844 5000
//   bun shot.ts "http://localhost:3457/?plshot=game" g.png 1440x900 3000 "document.querySelectorAll('input').length"
//
// NOTES
//   - `mobile: w < 700` makes Emulation report a mobile device, so media queries resolve
//     against the WxH you asked for. This is a real reflow, not a zoom.
//   - If a shot comes out blank, raise waitMs. 1800ms is usually too early for this app.
//   - Kill leftovers if a run dies: Get-Process msedge | Stop-Process -Force

const [url, out, size = '1440x900', waitArg = '4000', expr = ''] = process.argv.slice(2);
if (!url || !out) {
  console.error('usage: bun shot.ts <url> <out.png> [WxH] [waitMs] [expr]');
  process.exit(2);
}

const [w, h] = size.split('x').map(Number);
const port = 9300 + Math.floor(Math.random() * 500);

const CANDIDATES = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
];
const edge = CANDIDATES.find(p => require('node:fs').existsSync(p)) ?? CANDIDATES[0];

const os = require('node:os');
const path = require('node:path');
const profileDir = path.join(os.tmpdir(), `cdpshot-${port}`);

const proc = Bun.spawn([edge, '--headless=new', '--disable-gpu-sandbox', '--hide-scrollbars',
  `--remote-debugging-port=${port}`, `--user-data-dir=${profileDir}`,
  `--window-size=${w},${h}`, 'about:blank'], { stdout: 'ignore', stderr: 'ignore' });

let target: any;
for (let i = 0; i < 50 && !target; i++) {
  await Bun.sleep(200);
  try {
    target = (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find((t: any) => t.type === 'page');
  } catch { /* not up yet */ }
}
if (!target) {
  console.error(`edge never exposed a page on port ${port}`);
  proc.kill();
  process.exit(1);
}

const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise(r => (ws.onopen = r));

let id = 0;
const pending = new Map<number, (v: any) => void>();
ws.onmessage = e => {
  const m = JSON.parse(String(e.data));
  // auto-accept native dialogs so a window.confirm() cannot hang the run
  if (m.method === 'Page.javascriptDialogOpening') {
    ws.send(JSON.stringify({ id: 99999, method: 'Page.handleJavaScriptDialog', params: { accept: true } }));
  }
  if (m.id && pending.has(m.id)) { pending.get(m.id)!(m.result ?? m.error); pending.delete(m.id); }
};
const send = (method: string, params: any = {}) =>
  new Promise<any>(r => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });

await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: w < 700 });
await send('Page.navigate', { url });
await Bun.sleep(Number(waitArg));

if (expr) {
  const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  console.log('val', JSON.stringify(r?.result?.value ?? r));
}

const shot = await send('Page.captureScreenshot', { format: 'png' });
const bytes = Buffer.from(shot.data, 'base64');
await Bun.write(out, bytes);

const title = await send('Runtime.evaluate', { expression: 'document.title' });
console.log('ok', `${out} ${(bytes.length / 1024).toFixed(0)}KB`, '|', title?.result?.value ?? '');

ws.close();
proc.kill();
process.exit(0);
