# Omni-plane-Travels 交接包

两件事：**6 个内置世界的存档**（覆盖六大系统），**2 个漏掉的 commit 补丁**。

生成时间：2026-11-17 23:3x（本机）
存档来源：主项目 `D:\Omni-plane-Travels`（v2.8.4）真实 UI 走完创建流程导出，**没有手写 JSON、没有调用任何 API**

---

## 一、saves/ —— 6 个世界存档

全部是标准 v2.0 `.save.zip`（`type=omni-plane-travels-save` / `version=2.0` / `schemaVersion=5`）。
导入方式：大厅 → **存档裂隙** → **导入存档** → 选文件。`accept=".json,.zip,application/json,application/zip"`，**不用解压**。

| 文件 | 世界 | 角色 | 覆盖的模块 |
|---|---|---|---|
| `01-japanese_school.日式校园·樱丘日常.save.zip` | 日式校园 | 藤原澄 / 17 / 女 / 高二学生 | simulation |
| `02-desire_metropolis.烟火人间·霓虹夜行.save.zip` | 烟火人间 | 陆昭 / 28 / 男 / 独立广告导演 | **stat** + simulation |
| `03-wuxia_world.武侠世界·江南烟雨.save.zip` | 武侠世界 | 沈砚秋 / 23 / 女 | **stat + progression + profession + dice** + simulation |
| `04-wasteland_apocalypse.末日废土·铁锈荒原.save.zip` | 末日废土 | 秦九 / 34 / 男 / 拾荒者 | **stat + progression** + simulation |
| `05-stranded_island.荒岛求生·潮汐孤岛.save.zip` | 荒岛求生 | 海因 / 26 / 女 / 远洋水手 | **survival** + simulation |
| `06-border_trade.边境贸易·关隘商队.save.zip` | 边境贸易 | 宋知舟 / 31 / 男 / 边贸行商 | **business** + simulation |

**六大系统覆盖**：`stat`(2/3/4) · `progression`(3/4) · `profession`(3) · `dice`(3) · `survival`(5) · `business`(6)。

### 每个存档里有什么（实测，不是推测）

- `round=0`、`messageCount=0`、`messages=[]` —— **这是刚创建完、一回合都还没跑的初始档**。用它是为了验证「新建 → 落库 → 导出」这条链路，以及各模块初始化出来的数据结构。**不是给你接着玩的中期档。**
- `customWorld.id === worldId` 且 `name` 有值 —— 导入时 `prepareWorld()` 会校验这两条，**自洽**，不会报「缺少世界定义」。
- `moduleStates` 内容举例：
  - `stat`（武侠）：`{playerState:{血量:120,体力值:50,dim1:45..dim6:60,reputation:10,melancholy:20}, runtime:{modifiers:{},base:{attrA:120,attrB:50,...},derived:{}}}`
  - `progression`：`{currentTierIndex:0,currentXP:0,availableStatPoints:0}`
  - `profession`：`{abilities:{天赋点:0,技能点:0,已解锁天赋:{},已掌握技能:{},已觉醒:{},装备槽:{},后天天赋:{},先天天赋:{},职业状态:{职业ID:null,职业名称:'无职业',职业等级:1,能力点:2,已解锁能力:{}}}, freeSkills:{}}`
  - `dice`：`{dice:{history:[]}}`
  - `survival`（荒岛）：`{resources:{water:{数量:3,最大值:10,name:'淡水',symbol:'💧',scarce:true,...}, food:{数量:2,最大值:10,name:'食物',...}}}`
  - `business`（边境）：`{assets:{资金:500,资产列表:[],交易日志:[],库存:{}}, runtime:{inventory:{},productionCycles:{}}}`
- `moduleCheckpoints` 数量随世界不同：日式校园 3 / 烟火人间 3 / 武侠 6 / 废土 4 / 荒岛 3 / 边贸 3。形状是 `{id:'', moduleId, reason:'', createdAt:'', state}` —— **快照行是空的，只有 `state` 有内容**。这是应用自己导出的原样，我没改过。

### 一个需要你知道的事实

`gameState.玩家` 只有 11 个键（`姓名,年龄,性别,身份信息,当前目标,性格,外貌,货币资源,物品栏,纪事系统,任务系统`），**没有** `生存状态` / `当前段位索引` / `生存资源` / `经营资产`。
那些数值全在 `moduleStates[i].state` 里。所以「看角色数值」要去 `moduleStates` 找，不要指望 `gameState.玩家`。

---

## 二、patches/ —— 2 个漏掉的 commit

基线是 **`3bee9b2 chore(ui): 清除事件工作台遗漏的 !important`**（就是打包进 zip 的那个 HEAD）。它后面紧接的两个：

```
67bf247  test(presets): 冻结内置预设占位条目，供后续重构遵守
9302924  docs(handoff): 逻辑层重构与亮色主题两份新会话提示词
```

- `0001-test-presets.patch` —— `CLAUDE.md` +8 行 / `src/data/presetPlaceholders.test.ts` +31 行（2 files, 39 insertions）
- `0002-docs-handoff.patch` —— `docs/handoff/logic-refactor-session.md` +52 行 / `docs/handoff/theme-dawn-session.md` +75 行（2 files, 127 insertions）

**只动这 4 个文件，没有一处主题代码。**（`theme` 关键字在 patch 里出现 5 次，全在 `theme-dawn-session.md` 的文档正文中。）

### 应用方式

在 `3bee9b2` 上：

```bash
git am 0001-test-presets.patch 0002-docs-handoff.patch
```

或者（两个 patch 都只新增文件，`git apply` 也行）：

```bash
git apply 0001-test-presets.patch
git apply 0002-docs-handoff.patch
```

### 已做的一致性验证

在 `3bee9b2` 上按顺序 `git am` 这两个 patch 之后，`HEAD^{tree}` = `1097b5c1c31bedd7d88a1a408832631812fd6ae4`，与真仓库 `9302924^{tree}` **逐字节一致**。

### 注意

真仓库现在已经在 `d4f2210`（`3bee9b2` 之后 7 个提交，后面 5 个是「晨雾琉璃」主题），而且工作树上有未提交改动。
**如果你要用这两个 patch，必须在一个干净的 `3bee9b2` 检出上做**，直接对 `d4f2210` 打会冲突。
如果那台机子拿到的 zip 就是 `3bee9b2`，那正好，直接 `git am`。

---

## 三、怎么复核我给的数字

`patches/_verify-saves.json` 是逐档解压后读出来的原始报告（worldId / 模块 / 玩家 / 消息数 / checkpoint 数），不是手写的。

想自己再验一遍，把任意一个 `.save.zip` 解开（它本身就是 zip），里面有：

```
save.json            ← 全部数据
assets/manifest.json ← 25 B
```

`save.json` 开头就是 `{"type":"omni-plane-travels-save","version":"2.0","exportedAt":...,"save":{...}}`。

---

## 四、这份包是怎么做的（可复现）

不是手搓。用无头 Edge + CDP 驱动主项目的真实界面：

1. 起主项目服务（`server.ts` 里端口写死 3456，本机被 ComfyUI 占着绑定态，所以我复制了一份只改端口到 3466 跑，**主项目源文件一个字节没动**）
2. 点「点击任意处开始」→ 大厅 → 点世界水晶 → 「选择并继续」
3. 填姓名 / 年龄 / 性格 / 外貌 / 背景 / 职业，**最后**点性别（`identityReady` 要求 name + gender + age 三者齐备）
4. 「下一步」→ 跳过经历 → 起名弹窗填存档名 → 「开始冒险」
5. 没配 API 所以落在设置页，点返回回到大厅 → 存档裂隙 → 点「导出存档」

6 个世界全程 126.7 秒，**fail=0**。每一步都有日志（109 步）。

两个踩到的真坑，写下来给以后省时间：

- **性别按钮点不中**：`press('女')` 会被文本模糊匹配到别的元素（性格描述里也有「女」字样），必须 `all('button.gender-radio').find(x => norm(x.textContent) === norm('女'))` 精确匹配，而且**要放在最后点**，否则后续 setInput 触发的重渲染会把性别选择冲掉。
- **`.click()` 推不动 React 的 `EntrySlicedButton`**：得用 CDP 真实鼠标事件 `Input.dispatchMouseEvent`（mousePressed + mouseReleased）打到元素矩形中心。
